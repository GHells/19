package Model;

import java.util.ArrayList;
public class Cadastro {
    private ArrayList<Contato> lista;
    
    public Cadastro(){
        this.lista = new ArrayList<>();        
    }
    public ArrayList<Contato> getLista() {
        return lista;
    }
    public void setLista(ArrayList<Contato> lista) {
        this.lista = lista;
    }
    @Override
    public String toString() {
        return "Lista de Contatos: \n" + lista;
    }
    
    public void cadastrar(Contato p1){
        this.lista.add(p1);
    }
    public void excluir(Contato p1){
        this.lista.remove(p1);
    }
    public int verCelular(){
        return this.lista.size();
    }
    public Contato pesquisarContato(int celular){
        Contato achei = null;
        for(int i=0; i<this.lista.size(); i++){
            if(this.lista.get(i).getCelular()==celular){
                achei = this.lista.get(i);
            }
        }
        return achei;
    }
}
