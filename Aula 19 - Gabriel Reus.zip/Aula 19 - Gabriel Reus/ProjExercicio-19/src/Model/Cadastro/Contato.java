package Model;

public class Contato {
    private int codigo;
    private String nome;
    private int celular;
    private int residencial;
    private String email;
    
    public Contato(){
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCelular() {
        return celular;
    }

    public void setCelular(int celular) {
        this.celular = celular;
    }

    public int getResidencial() {
        return residencial;
    }

    public void setResidencial(int residencial) {
        this.residencial = residencial;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
   
    @Override
    public String toString() {
        return "\n"+
               "-----------------------" +
               "\nContato: " + 
               "\nCódigo: " + codigo + 
               "\nNome: " + nome + 
               "\nTelefone Celular: " + celular + 
               "\nTelefone Residencial: " + residencial +
               "\nE-mail: " + email +
               "\n-----------------------"+
               "\n";
        
    }
}