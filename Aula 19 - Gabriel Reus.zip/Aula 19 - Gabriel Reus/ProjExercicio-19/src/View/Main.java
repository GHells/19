package View;


import Model.Cadastro;
import Model.Contato;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        //Instancia a classe que tem ArrayList
        Cadastro c1 = new Cadastro();
        byte menu;
        do{
            System.out.println("1 - Cadastrar Contato:\n" +
                               "2 - Ver Contatos Cadastrados\n" +
                               "3 - Ver Quantidade de Contatos Cadastrados\n" +
                               "4 - Excluir Contato \n" +
                               "5 - Pesquisar Contatos \n"+
                               "0 - Sair");
            menu = ler.nextByte();
            switch(menu){
                case 1:
                    System.out.println("\nCADASTRANDO...");
                    Contato p1 = new Contato();
                    System.out.println("\nDigite o código do Contato: ");
                    p1.setCodigo(ler.nextInt());
                    System.out.println("Digite o nome: ");
                    ler.nextLine();
                    p1.setNome(ler.nextLine());
                    System.out.println("Digite o Número do Celular: ");
                    p1.setCelular(ler.nextInt());
                    System.out.println("Digite o Número do Residencial: ");
                    p1.setResidencial(ler.nextInt());
                    System.out.println("Digite o E-mail: ");
                    ler.nextLine();
                    p1.setEmail(ler.nextLine());
                    //Colocando o produto no ArrayList
                    c1.cadastrar(p1);
                    System.out.println("\nCadastrado com sucesso!\n");
                    break;
                case 2:
                    System.out.println("\nVISUALIZANDO...");
                    if(c1.getLista().isEmpty()){
                        System.out.println("\nNão há contatos cadastrados.");
                    }else{
                        System.out.println(c1);
                    }
                    break;
                case 3:
                    System.out.println("\nCELULARES...");
                    System.out.println(c1.verCelular()+"\n");
                    break;
                case 4:
                    System.out.println("\nEXCLUINDO...");
                    if(c1.getLista().isEmpty()){
                        System.out.println("Não Existem Contatos para Remover. ");
                    }else{
                        System.out.println("Digite o código do contato: ");
                        int codigo = ler.nextInt();
                        Contato encontrado = c1.pesquisarContato(codigo);
                        if(encontrado==null){
                            System.out.println("Não foi encontrado contato com este código.");
                        }else{
                            System.out.println("Tem certeza que que deseja excluir?"
                                    + "\n1-Sim"
                                    + "\n2-Não");
                            byte op = ler.nextByte();
                            if(op==1){
                                c1.excluir(encontrado);
                                System.out.println("Removido com Sucesso.");
                            }else{
                                System.out.println("Opção cancelada.");
                            }                        
                        }
                    }
                    break;
                case 5:
                    System.out.println("Pesquisar Contatos: ");                   
                   
                    if(c1.getLista().isEmpty()){    
                        System.out.println("\nNão foi Econtrado Nenhum Contato");
                    }else{
                        System.out.println("\nDigite o Celular do Contato para Pesquisarmos: ");
                    int telCelular = ler.nextInt();
                     Contato achei = c1.pesquisarContato(telCelular);
                        if(achei == null){
                            System.out.println("Nenhum contato foi encontrado!");
                        } else{
                            System.out.println("Contato encontrado!");
                            System.out.println(achei);
                        }
                    }
                    break;
                case 0:
                    System.out.println("Volte sempre!");
                   break;
                default:
                    System.out.println("Erro! Opção inválida");              
            }            
        }while(menu!=0);
    }    
}
